const mongoose=require('mongoose')
const Schema=mongoose.Schema
const passportLocalMongoose=require('passport-local-mongoose');
var Country=new Schema({
	id:{
		type:Number
	},
	name:{
		type:String
	},
	password:{
		type:String
	},
	dob:{
		type:Date
	},
	address:{
		type:String
	}
})
Country.plugin(passportLocalMongoose);
module.exports=mongoose.model('Country',Country)

