const express = require('express')
const router = express.Router()
const userControllers=require('../controllers/user.controllers');
//Retrieve all users
router.get('/',userController.findAll);
//create new users
router.post('/',userController.create);
//Retrieve a single user with id
router.get('/:id',userController.findone);
//update a user with id
router.put('/:id',userController.update);
//delete a user with id
router.delete('/:id',userController.delete);
module.exports=router