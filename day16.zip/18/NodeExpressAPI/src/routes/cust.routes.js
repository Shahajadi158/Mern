const express = require('express')
const router = express.Router()
const custController=require('../controllers/cust.controllers');
//Retrieve all users
router.get('/',custController.findAll);
//create new users
router.post('/',custController.create);
//Retrieve a single user with id
router.get('/:id',custController.findone);
//update a user with id
router.put('/:id',custController.update);
//delete a user with id
router.delete('/:id',custController.delete);
module.exports=router