const mongoose = require('mongoose');
const customer = mongoose.Schema({

    cid: Number,
    cpan:String,
    cadhar:String,
    cdob:Date,
    
}, {
    timestamps: true
});

module.exports = mongoose.model('customer', customer);