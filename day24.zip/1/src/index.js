import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import Fruits from './App';
//import reportWebVitals from './reportWebVitals';
/*
const myelement=<h1>hello{15+5}ok</h1>
const container=document.getElementById("root")
const root = ReactDOM.createRoot(container);
root.render(myElement);
  /* <React.StrictMode>
    <App />
  </React.StrictMode>


// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
  const myElement=<h1>hello{15+5}ok</h1>
  const container=document.getElementById("root")
const root = ReactDOM.createRoot(container);
root.render(myElement);
const myElement=(
  <ul>
  <li>apple</li>
  <li>mango</li>
  <li>banana</li>
  </ul>
  );
const container=document.getElementById("root")
const root = ReactDOM.createRoot(container);
root.render(myElement);
const x=50;
let text = "Google engine";
if(x<100){
  text="Yaaho engine";
}
function Mongo(){
  return <h1 className="myclass">Welcome to classes of mongo</h1>
}
const myelement=(
  <table className="tb">
  <tr id="r1">
  <th>Name</th>
  <th>age</th>
  <th>Address</th>
  </tr>
  <tr id="r2">
  <td>saisri</td>
  <td>20</td>
  <td>AP</td>
  </tr>
  <tr id="r3">
  <td>Renuka</td>
  <td>19</td>
  <td>AP</td>
  </tr>
  <tr id="r4">
  <td>Sarayu</td>
  <td>19</td>
  <td>AP</td>
  </tr>
  </table>
  );*/
  const container=document.getElementById("root")
const root = ReactDOM.createRoot(container);
root.render(<Fruits/>);