import image from './image1.jfif';
import video from './WhatsApp Video 2024-08-05 at 10.24.13 AM (1).mp4'
import Audio from './WhatsApp Audio 2024-08-06 at 2.54.45 AM.mpeg';
//import './App.css';

/*function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}
*/
import React,{Component}from 'react';
class Fruits extends React.Component{
  render(){
    return(
      <div className="ok">
      <Apple/>
      <Banana/>
      <Pineapple/>
      <Grapes/>
      </div>
      );
  }
}
class Apple extends React.Component{
  render(){
    return(
      <div>
     <img src={image} className="Fruits-logo" alt='logo'/>
      </div>
      );
  }
}
class Banana extends React.Component{
  render(){
    return(
      <div>
      <video src={video} className="Fruits-video" alt='video' controls/>
      </div>
      );
  }
}
class Pineapple extends React.Component{
  render(){
    return(
      <div>
     <audio src={Audio} className="Fruits-Audio" alt='Audio' controls/>
      </div>
      );
  }
}
class Grapes extends React.Component{
  render(){
    return(
      <div>
     <form>
     <label> Name:<input type="text"/></label><br/>
    <label> clg Name:<input type="text"/></label><br/>
    <button>Submit</button>
     </form>
      </div>
      );
  }
}
export default Fruits;
