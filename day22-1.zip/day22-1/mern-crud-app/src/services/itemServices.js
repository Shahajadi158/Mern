import axios from 'axios';
const API_URL = 'http://localhost:5000/items/';
export const getItems=()=>axios.get(API_URL);
export const addItems=(item)=>axios.post(API_URL,item);
export const updateItems=(id,item)=>axios.put(`${API_URL}${id}`,item);
export const deleteItems=(id)=>axios.delete(`${API_URL}${id}`);
