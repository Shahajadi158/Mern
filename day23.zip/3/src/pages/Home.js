const Home=()=>{
	return <h1 className="home">A paragraph is a group of sentences that fleshes out a single idea. In order for a paragraph to be effective, it must begin with a topic sentence, have sentences that support the main idea of that paragraph, and maintain a consistent flow. • presents a single idea.
	</h1>
};
export default Home;